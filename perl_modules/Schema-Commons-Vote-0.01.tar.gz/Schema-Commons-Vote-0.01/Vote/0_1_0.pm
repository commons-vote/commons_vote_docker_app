package Schema::Commons::Vote::0_1_0;

use base qw(DBIx::Class::Schema);
use strict;
use warnings;

our $VERSION = 0.01;

__PACKAGE__->load_namespaces;

1;

__END__
