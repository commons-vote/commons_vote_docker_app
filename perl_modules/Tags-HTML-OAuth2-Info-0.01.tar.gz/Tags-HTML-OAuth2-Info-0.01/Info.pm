package Tags::HTML::OAuth2::Info;

use base qw(Tags::HTML);
use strict;
use warnings;

use Error::Pure qw(err);
use Unicode::UTF8 qw(decode_utf8);

our $VERSION = 0.01;

# Constructor.
sub new {
	my ($class, @params) = @_;

	# No CSS support.
	push @params, 'no_css', 1;

	my $self = $class->SUPER::new(@params);

	# Object.
	return $self;
}

sub _process {
	my ($self, $oauth2_hr) = @_;

	if (! exists $oauth2_hr->{'id'}) {
		err "Key 'id' is required.";
	}
	if (! exists $oauth2_hr->{'login'}) {
		err "Key 'login' is required.";
	}
	if (! $oauth2_hr->{'login'} && ! exists $oauth2_hr->{'authorization_url'}) {
		err "Key 'authorization_url' is required.";
	}

	$self->{'tags'}->put(
		['b', 'html'],
		['b', 'body'],
		['b', 'div'],
		['a', 'class', 'head'],
		['d', 'ID: '.$oauth2_hr->{'id'}],
		['b', 'a'],
		['a', 'style', 'float:right;'],
	);
	if ($oauth2_hr->{'login'}) {
		$self->{'tags'}->put(
			['a', 'href', '/logout'],
			['d', 'Logout'],
		);
	} else {
		$self->{'tags'}->put(
			['a', 'href', $oauth2_hr->{'authorization_url'}],
			['d', 'Login'],
		);
	}
	$self->{'tags'}->put(
		['e', 'a'],
		['b', 'hr'],
		['a', 'style', 'clear:both;'],
		['e', 'hr'],
		['e', 'div'],

		['b', 'div'],
		['a', 'class', 'content'],
	);
	if ($oauth2_hr->{'login'}) {
		$self->{'tags'}->put(
			['b', 'div'],
			['a', 'style', 'border: 1px solid black;'],
		);
		if (exists $oauth2_hr->{'token_string'}
			&& exists $oauth2_hr->{'token_string'}->{'string'}) {

			$self->{'tags'}->put(
				['b', 'a'],
				['a', 'href', '/token_string_dump?view=0'],
				['d', decode_utf8('Vypnout zobrazení dumpu')],
				['e', 'a'],

				['b', 'pre'],
				['d', $oauth2_hr->{'token_string'}->{'string'}],
				['e', 'pre'],

				['b', 'dl'],
				['b', 'dt'],
				['d', 'Token string expired'],
				['e', 'dt'],
				['b', 'dd'],
				['d', $oauth2_hr->{'token_string'}->{'expires_in'}],
				['e', 'dd'],

				['b', 'dt'],
				['d', 'Can refresh token string'],
				['e', 'dt'],
				['b', 'dd'],
				['d', $oauth2_hr->{'token_string'}->{'can_refresh_tokens'}],
				['e', 'dd'],
				['e', 'dl'],
			);
		} else {
			$self->{'tags'}->put(
				['b', 'a'],
				['a', 'href', '/token_string_dump?view=1'],
				['d', 'Zobrazit dump'],
				['e', 'a'],
			);	
		}
		$self->{'tags'}->put(
			['e', 'div'],
		);
		if (exists $oauth2_hr->{'profile'}) {
			$self->{'tags'}->put(
				exists $oauth2_hr->{'profile'}->{'picture'} ? (
					['b', 'img'],
					['a', 'src', $oauth2_hr->{'profile'}->{'picture'}],
					['a', 'style', 'float:right;'],
					['e', 'img'],
				) : (),

				['b', 'dl'],
				['a', 'style', 'clear:left;'],
			);
			foreach my $item (keys %{$oauth2_hr->{'profile'}}) {
				if ($item eq 'picture') {
					next;
				}
				my $value_ar = [];
				if (ref $oauth2_hr->{'profile'}->{$item} eq '') {
					my $value = "$oauth2_hr->{'profile'}->{$item}";
					$value_ar = [['d', decode_utf8($value)]];
				} elsif (ref $oauth2_hr->{'profile'}->{$item} eq 'ARRAY') {
					foreach my $value (@{$oauth2_hr->{'profile'}->{$item}}) {
						if (@{$value_ar}) {
							push @{$value_ar}, ['b', 'br'], ['e', 'br'];
						}
						push @{$value_ar}, ['d', decode_utf8($value)];
					}
				}
				$self->{'tags'}->put(
					['b', 'dt'],
					['d', $item],
					['e', 'dt'],
					['b', 'dd'],
					@{$value_ar},
					['e', 'dd'],
				);
			}
		}
		$self->{'tags'}->put(
			['e', 'dl'],
		);
	} else {
		$self->{'tags'}->put(
			['d', decode_utf8('Obsah není přístupný.')],
			$oauth2_hr->{'error'} ? (
				['b', 'p'],
				['a', 'style', 'color:red'],
				['d', $oauth2_hr->{'error'}],
				['e', 'p'],
			) : (),
		);
	}
	$self->{'tags'}->put(
		['e', 'div'],
		['e', 'body'],
		['e', 'html'],
	);

	return;
}

1;
